function print() {
  console.log("Welcome to Angular");
}

print();
