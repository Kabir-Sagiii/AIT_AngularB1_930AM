// import users from "./First.mjs";

// console.log(users); // yes or no or error

import { Products } from "./First.mjs";

var obj1 = new Products();
obj1.display();
