import Products from "./Product.js";

var obj1 = new Products();

obj1.display();
obj1.changePrice(150000);
