var data = [100, 200, 300];
var brand = ["Apple", "Samsung", "Vivo"];
console.log(data, brand);
