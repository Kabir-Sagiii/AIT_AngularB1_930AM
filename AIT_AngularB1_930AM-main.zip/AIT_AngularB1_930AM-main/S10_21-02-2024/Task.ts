
// let price:any =true 

// price = 100

// let rating:unknown = 4.5 

// rating = "fdjvdfjv dfnm "


    let priceProduct:any = true

        if(priceProduct === 100){  //true
            console.log("..........")
        } else {
            console.log("---------------")
        }

        let data:unknown ; // undefined //undefined

          if(data === true){ // boolean of data
            console.log("=======")
          }else {
            console.log("-------------")
          }

           data = "cmdsn cnsmdc"
           console.log(data)