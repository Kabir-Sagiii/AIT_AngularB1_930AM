var info = ["Macbook", 100, true];
var username = "Raj Verma";
username = 100;
