var data:number[] = [100,200,300]

var brand:Array<string> = ["Apple","Samsung","Vivo"]

console.log(data,brand)
