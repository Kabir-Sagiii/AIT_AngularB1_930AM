

function f1():void{

    console.log("Not Returning")
   
}