var info:any[]= ["Macbook",100,true]

var username:any = "Raj Verma"

username = 100

var datas:[string,number] = ["Raj",101]

datas = ["Raj", 1000]