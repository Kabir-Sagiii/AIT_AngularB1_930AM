// let price:any =true 
// price = 100
// let rating:unknown = 4.5 
// rating = "fdjvdfjv dfnm "
var priceProduct = 100;
if (priceProduct === 100) { //true
    console.log("..........");
}
else {
    console.log("---------------");
}
var data; // undefined //undefined
if (data === true) { // boolean of data
    console.log("=======");
}
else {
    console.log("-------------");
}
data = "cmdsn cnsmdc";
console.log(data);
