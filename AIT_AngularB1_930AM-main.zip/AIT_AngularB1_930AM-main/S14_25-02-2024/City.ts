class City{
    city:string;
    constructor(){
        this.city = "Mumbai"
    }

    changeCity(newCity:string):string{
        this.city = newCity
            return this.city
        }
}