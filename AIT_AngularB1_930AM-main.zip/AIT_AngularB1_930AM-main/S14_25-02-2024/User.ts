class User{
    username:string;
   

    constructor(){
        this.username = "Raj Verma"
       
    }

    
}