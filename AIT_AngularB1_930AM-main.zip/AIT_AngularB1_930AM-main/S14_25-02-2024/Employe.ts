class Employee{
    empname:string;
    

    constructor(){
        this.empname = "Rohan sharma"
       
    }

    
}