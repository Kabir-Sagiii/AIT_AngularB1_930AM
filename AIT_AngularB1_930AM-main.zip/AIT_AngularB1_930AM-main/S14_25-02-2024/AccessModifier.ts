class AccessModifiers {

    public username:string 

    private id:number

    protected isMarried:boolean;

}