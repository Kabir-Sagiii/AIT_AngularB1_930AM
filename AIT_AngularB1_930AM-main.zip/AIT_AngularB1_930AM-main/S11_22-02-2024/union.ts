let dummy:string | number | boolean | object= "Raj" //string

dummy =   false  //number

dummy = {name:"Kabir"}

dummy = ["smdcmdcb"]