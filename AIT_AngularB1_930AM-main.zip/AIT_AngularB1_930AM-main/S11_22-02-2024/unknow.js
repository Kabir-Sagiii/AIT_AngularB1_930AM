// var city :unknown = "pune"
// var anothercity :string = city
function fn(f) {
    f(); // this not valid statement
}
fn(function () { console.log("cdsn cdmnsc sdmn"); });
