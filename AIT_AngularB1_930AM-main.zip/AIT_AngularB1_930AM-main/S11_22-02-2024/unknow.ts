
// var city :unknown = "pune"

// var anothercity :string = city

  function fn(f:unknown):void{

        // f() // this not valid statement

  }

    fn(()=>{console.log("cdsn cdmnsc sdmn")})