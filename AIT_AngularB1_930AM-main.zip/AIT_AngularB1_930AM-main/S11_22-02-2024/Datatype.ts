
// case : 1
// let firstName:string = "Ayush"

// let anotherName :string ;

// anotherName = firstName ;

// console.log(firstName,anotherName)

// //case 2

// let firstName:string = "Ayush"

// let anotherName:number;

// anotherName = firstName

// //case 3

// let firstName:any = "Ayush"

// let anotherName:string;

// anotherName = firstName

// console.log(firstName,anotherName)

// //case 4

// let firstName:any = "Ayush"

// firstName = 100

// let anotherName:string;

// anotherName = firstName

// console.log(firstName,anotherName)

//case 4

let firstName:unknown = "Sonali"

// firstName = 100

firstName = "cdsj cnsdmc"

let anotherName:string = "Raj"

// firstName = anotherName
anotherName= firstName

// anotherName =

console.log(firstName,anotherName)





