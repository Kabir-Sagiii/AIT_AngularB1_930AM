
let uname:string = "Raj Verma"

let city = true

let data:string[] = ["Raj","Rohit","Ramesh"]

let dummyS = undefined

let dummyA = null  // null -----> object

let fn = ()=>{console.log("my function")}

console.log(typeof fn) //object ----> function ?

