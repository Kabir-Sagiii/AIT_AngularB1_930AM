// case : 1
// let firstName:string = "Ayush"
// let anotherName :string ;
// anotherName = firstName ;
// console.log(firstName,anotherName)
// //case 2
// let firstName:string = "Ayush"
// let anotherName:number;
// anotherName = firstName
// //case 3
// let firstName:any = "Ayush"
// let anotherName:string;
// anotherName = firstName
// console.log(firstName,anotherName)
//case 4
var firstName = "Ayush";
firstName = 100;
var anotherName;
anotherName = firstName;
console.log(firstName, anotherName);
