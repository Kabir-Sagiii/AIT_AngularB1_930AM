var uname = "Raj Verma";
var city = true;
var data = ["Raj", "Rohit", "Ramesh"];
var dummyS = undefined;
var dummyA = null; // null -----> object
var fn = function () { console.log("my function"); };
console.log(typeof fn);
