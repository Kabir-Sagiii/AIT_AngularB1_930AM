
interface IUsers {
    uname:string,
    city:string,
    phone:number,
    gender?:string
}

  let userObj1 : IUsers = {
    uname : "Raj",
    city:"Delhi",
    phone:98987876,
   
  }

    userObj1.gender="male"

// userObj.uname = 98

// userObj.city = "cmds cdsmnc dmsn c"