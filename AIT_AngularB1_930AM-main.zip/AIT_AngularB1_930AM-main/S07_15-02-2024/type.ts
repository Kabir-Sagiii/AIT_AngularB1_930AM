var city : string ="Kabir"

// city = 101 Not  allowed

var obj = {
    id:101
}

// obj.id = true Not Allowed

var username = "Sagar"  // String  

// username = 101 // Not Allowed

