var rate = 2.5;

var product = {
  "brand Name": "Apple",
  model: "Iphone 15 Pro Max",
  price: 160000,
};

// console.log(product["brand Name"]);

product.rating = rate;
console.log(product);
console.table(product);
