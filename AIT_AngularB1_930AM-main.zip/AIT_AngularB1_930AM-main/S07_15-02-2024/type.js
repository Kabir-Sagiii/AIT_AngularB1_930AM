var name = "Raj"; // String

name = 101; //number

name = "Sneha";

var obj = {
  id: 101,
};

obj.id = true;
