var { city, add } = require("./City.js"); // C = {city:"Delhi"}

console.log(city);

add();
