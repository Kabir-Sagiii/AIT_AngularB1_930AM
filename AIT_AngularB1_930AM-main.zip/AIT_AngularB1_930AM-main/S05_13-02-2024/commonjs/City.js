var city = "Mumbai";

function add() {
  console.log(15 + 15);
}

module.exports = { city, add };
