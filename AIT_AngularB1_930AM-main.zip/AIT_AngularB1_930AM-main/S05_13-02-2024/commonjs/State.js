var state = "MH";

module.exports = { state };
