var cityFile = require("./City.js"); // myobj = {city:"Delhi"}
var stateFile = require("./State.js");

console.log(cityFile.city);
console.log(stateFile.state);

cityFile.add();
