export var mycity = "Hyderabad"; // Named Export

export var anotherCity = "Pune";

var myName = "Kabir";

var newCity = "Indore From MP";

export default newCity;
