import { anotherCity, mycity } from "./City.mjs";
import { printName } from "./Name.mjs";

console.log(anotherCity);
console.log(mycity);

printName();
