import { mycity } from "./City.mjs"; // Named Import

console.log(mycity);
