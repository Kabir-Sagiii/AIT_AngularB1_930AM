export function printName() {
  console.log("Raj Verma");
}

function generatePin() {
  // -------Some Logic-------
}
