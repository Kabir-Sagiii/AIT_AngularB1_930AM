import newCity from "./City.mjs"; // Default Import

console.log(newCity);
