var information = ["Sagar", "Kabir"];
var ids = [101, 200];
information = ["cjdcn"];
var data = ["cdsjcjds", 100];
data = ["Kabir", 100];
console.log(information, ids);
console.log(data);
