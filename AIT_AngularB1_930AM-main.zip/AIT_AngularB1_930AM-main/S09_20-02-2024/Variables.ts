let city:string = "Delhi"    // Delhi or Mumbai

city = "Mumbai"; 

city = "Hyderabad";

let id : number = 101    // 101 or 1000

id = 1000

console.log(city,id)