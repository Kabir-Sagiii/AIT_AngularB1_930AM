
let information:string[] = ["Sagar","Kabir"]

let ids:number[] = [101,200]

information = ["cjdcn"]

let data:[string,number] = ["cdsjcjds",100]

 data = ["Kabir",100]

console.log(information,ids)
console.log(data)

