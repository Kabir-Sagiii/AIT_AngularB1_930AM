var city = "Delhi"; // Delhi or Mumbai
city = "Mumbai";
city = "Hyderabad";
var id = 101; // 101 or 1000
id = 1000;
console.log(city, id);
