class A{

    city:string= "Delhi"

    a1(x:string):void{
      this.city = x 
    }

    a1(x:number):void{
          this.city = "vdfjv jkdfvfdjk"
    }
}