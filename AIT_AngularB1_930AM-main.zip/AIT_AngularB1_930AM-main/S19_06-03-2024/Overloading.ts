class Users {

    name:string;
    id:number;

    // display():void {
    //     console.log(this.name,this.id)
    // }

    // display(name:string,id:number):void {
    // this.name = name 
    // this.id = id
    // console.log(this.name,this.id)
    // }
}