class Authentication{


    register(email:string,name:string):void{
     //------------------------
    }
}

class fbAuthentication extends Authentication{
      register(){
        //own implementation
      }
}

class googleAuth extends Authentication {
    register(){
        //own implemntation
    }
}