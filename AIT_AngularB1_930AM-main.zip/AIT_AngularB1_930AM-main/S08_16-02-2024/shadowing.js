// var rating = 4.5;

// var rating = 5.5;

// console.log(rating);

// let rating = 4.5

// let rating = 6.9

// const code = 99

// const code = 88
