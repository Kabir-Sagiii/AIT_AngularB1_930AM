var city:string = "Mumbai"

city = "Pune"

// let id:number = 101

id = 1000

var pin = true

pin = false