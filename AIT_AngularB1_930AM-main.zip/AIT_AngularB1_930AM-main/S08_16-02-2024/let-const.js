let username = "Kabir";

username = "Sagar";

const pin = 413;

// pin = 345;

console.log(username);
